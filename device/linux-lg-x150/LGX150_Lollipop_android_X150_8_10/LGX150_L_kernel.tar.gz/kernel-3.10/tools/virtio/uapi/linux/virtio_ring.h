#ifndef VIRTIO_RING_H
#define VIRTIO_RING_H
#include "../../../../include/uapi/linux/virtio_ring.h"
#endif /* VIRTIO_RING_H */
