#define DEFINE_RATELIMIT_STATE(name, interval_init, burst_init)	int name = 0

#define __ratelimit(x) (*(x))

