#include "../../../include/linux/kern_levels.h"

#define printk printf
#define vprintk vprintf
