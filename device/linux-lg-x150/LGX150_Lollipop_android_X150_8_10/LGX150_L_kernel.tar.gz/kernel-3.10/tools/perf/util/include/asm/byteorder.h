#include <asm/types.h>
#include "../../../../include/uapi/linux/swab.h"
