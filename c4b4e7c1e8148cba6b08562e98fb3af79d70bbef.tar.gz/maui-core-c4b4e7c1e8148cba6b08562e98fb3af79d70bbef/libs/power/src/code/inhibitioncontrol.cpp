#include "inhibitioncontrol.h"

InhibitionControl::InhibitionControl(QObject *parent) : QObject(parent)
{

}
