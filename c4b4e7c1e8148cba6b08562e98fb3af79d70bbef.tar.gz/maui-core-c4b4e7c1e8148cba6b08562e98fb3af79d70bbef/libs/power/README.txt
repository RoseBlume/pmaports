TODO:
======
- Sleepstates don't match what solidshell reports
- ac plug state does not get updated
- this engine probably shares some functionality with
  the solidengine, have a look at that and evaluate

Notes
======
There's a battery applet (also in kdebase) which uses this engine

-- sebas

